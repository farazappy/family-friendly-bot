var Discord = require ('discord.io');
var logger= require('winston');
var auth = require('./auth.json');

var fs = require('fs');

logger.remove(logger.transports.Console);
logger.add(new logger.transports.Console, {
	colorize: true
});

logger.level = 'debug';

var bot = new Discord.Client({
	token: auth.token,
	autorun: true
});

bot.on('ready', function (event) {
	logger.info('Connected');
	logger.info('Logged in as: ');
	logger.info(bot.username + ' - (' + bot.id + ')');
});

bot.on('message', function(user, userId, channelId, message, event) {

	var serverId = bot.channels[channelId].guild_id;

	if(message.substring(0,1) == '!') {
		var args = message.substring(1).split(' ');
		var cmd = args[0];

		args = args.splice(1);

		var voiceChannelId = bot.servers[serverId].members[userId].voice_channel_id;

		if(userId == '202744505114296331')
			bot.sendMessage({
				to: channelId,
				message: 'Sorry ' + user + ', I won\'t serve you!'
			});

		switch(cmd) {
			case 'ping':
				bot.sendMessage({
					to: channelId,
					message: 'Pong!'
				});
				break;
			case 'hi':
				bot.sendMessage({
					to: channelId,
					message: 'Konichiwa ' + user + '! Uwu~~~'
				});
				break;
			case 'meepo':

				if(!voiceChannelId)
					bot.sendMessage({
						to: channelId,
						message: user + ' behenchod pehle voice channel join kar!'
					});
				else {
					bot.joinVoiceChannel(voiceChannelId, function(error, event) {
						if(error)
							console.log(error);
						else {
							bot.getAudioContext(voiceChannelId, function(error, stream) {
								if(error)
									console.log(error);
								else {
									fs.createReadStream('meepo_laugh.mp3').pipe(stream, {end: false});

									stream.on('done', function() {
										bot.leaveVoiceChannel(voiceChannelId, function(){
											console.log('Done!');
										});
									})
								}
							});
						}
					});
				}
				break;
			case 'jhola':
				if(!voiceChannelId)
					bot.sendMessage({
						to: channelId,
						message: user + ' behenchod pehle voice channel join kar!'
					});
				else {
					bot.joinVoiceChannel(voiceChannelId, function(error, event) {
						if(error)
							console.log(error);
						else {
							bot.getAudioContext(voiceChannelId, function(error, stream) {
								if(error)
									console.log(error);
								else {
									fs.createReadStream('jhola.wma').pipe(stream, {end: false});

									stream.on('done', function() {
										bot.leaveVoiceChannel(voiceChannelId, function(){
											console.log('Done!');
										});
									})
								}
							});
						}
					});
				}
				break;
			case 'good_morning':
				if(!voiceChannelId)
					bot.sendMessage({
						to: channelId,
						message: user + ' behenchod pehle voice channel join kar!'
					});
				else {
					bot.joinVoiceChannel(voiceChannelId, function(error, event) {
						if(error)
							console.log(error);
						else {
							bot.getAudioContext(voiceChannelId, function(error, stream) {
								if(error)
									console.log(error);
								else {
									fs.createReadStream('Modi_GM.mp3').pipe(stream, {end: false});

									stream.on('done', function() {
										bot.leaveVoiceChannel(voiceChannelId, function(){
											console.log('Done!');
										});
									})
								}
							});
						}
					});
				}
				break;
			case 'achha_kiya':
				if(!voiceChannelId)
					bot.sendMessage({
						to: channelId,
						message: user + ' behenchod pehle voice channel join kar!'
					});
				else {
					bot.joinVoiceChannel(voiceChannelId, function(error, event) {
						if(error)
							console.log(error);
						else {
							bot.getAudioContext(voiceChannelId, function(error, stream) {
								if(error)
									console.log(error);
								else {
									fs.createReadStream('achha_kiya.wma').pipe(stream, {end: false});

									stream.on('done', function() {
										bot.leaveVoiceChannel(voiceChannelId, function(){
											console.log('Done!');
										});
									})
								}
							});
						}
					});
				}
				break;
			case 'waah':
				if(!voiceChannelId)
					bot.sendMessage({
						to: channelId,
						message: user + ' behenchod pehle voice channel join kar!'
					});
				else {
					bot.joinVoiceChannel(voiceChannelId, function(error, event) {
						if(error)
							console.log(error);
						else {
							bot.getAudioContext(voiceChannelId, function(error, stream) {
								if(error)
									console.log(error);
								else {
									fs.createReadStream('waah_modi.wma').pipe(stream, {end: false});

									stream.on('done', function() {
										bot.leaveVoiceChannel(voiceChannelId, function(){
											console.log('Done!');
										});
									})
								}
							});
						}
					});
				}
				break;
		}
	}
});